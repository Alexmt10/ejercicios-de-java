package tema4;

public class ejer6 {

	public static void main(String[] args) {
		
		System.out.println("Multiplos de 7 menores de 100");
		 for (int i = 7; i < 100; i += 7) {
	            System.out.println(i);
		 }
	

	}

}
