package ejerciciosrefuerzo;

public class ejer1for {

	public static void main(String[] args) {
		
		

		int num1 = 100;
		
		
		System.out.println("Los numeros entre 5 y 100 multiplos de 5 son:");
		
		//Calcula los números comprendidos entre 5 y 100 que sean multiplos de 5.
		for(int i = 5 ;i<=num1;i+=5) {
			
			System.out.println(i);
         }
		
		
	}

}

       //Este metodo me parece el más adecuado para este ejercicio porque para sumar numeros en una secuencia es el más sencillo de estructurar.
